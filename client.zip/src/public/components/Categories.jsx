import React from 'react'

const Categories = () => {
    return <>
        <div className='d-flex justify-content-center flex-column m-6'>
            <p className='fs-10'>Explore By Categories</p>
            <p >Great doctor if you need your family member to get effective immediate assistance, emergency treatment or a simple consultation.</p>
        </div>
        {/* <p className='d-flex justify-content-center'>Great doctor if you need your family member to get effective immediate assistance, emergency treatment or a simple consultation.</p> */}
    </>
}

export default Categories